<?php $__env->startSection('title', 'Rekap Aktivitas IT (Audit Trail)'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .stat-card {
        border-radius: 14px;
        transition: transform .18s ease, box-shadow .18s ease;
        border: 1px solid rgba(0, 0, 0, .05);
    }
    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 24px rgba(0, 0, 0, .08) !important;
    }
    .stat-icon {
        width: 52px;
        height: 52px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.45rem;
        flex-shrink: 0;
    }
    .filter-card {
        border-radius: 14px;
        border: 1px solid rgba(0, 0, 0, .05);
    }
    .filter-card .form-control,
    .filter-card .form-select,
    .filter-card .btn {
        height: 38px;
        font-size: .875rem;
        border-radius: 8px;
    }
    .table-card {
        border-radius: 14px;
        border: 1px solid rgba(0, 0, 0, .05);
        overflow: hidden;
    }
    .table-activity thead th {
        background: #1b7a5a !important;
        color: #ffffff !important;
        font-weight: 600;
        font-size: .84rem;
        letter-spacing: .3px;
        padding: .75rem .85rem;
        border: 0;
        vertical-align: middle;
    }
    .table-activity tbody td {
        padding: .7rem .85rem;
        vertical-align: middle;
        font-size: .875rem;
        border-bottom: 1px solid #edf2f0;
    }
    .table-activity tbody tr:hover {
        background-color: #f6faf8;
    }
    .badge-action {
        width: 82px;
        display: inline-block;
        text-align: center;
        font-weight: 600;
        font-size: 11px;
        padding: 5px 0;
        border-radius: 6px;
        letter-spacing: .3px;
    }
    .per-page-pill {
        border-radius: 20px;
        padding: .25rem .75rem;
        font-size: .8rem;
        font-weight: 600;
    }
    .pagination {
        gap: 4px;
        margin-bottom: 0;
    }
    .pagination .page-item .page-link {
        color: #1b7a5a;
        border-radius: 6px !important;
        border: 1px solid #dee2e6;
        padding: 0.35rem 0.75rem;
        font-weight: 500;
        font-size: 0.85rem;
        background-color: #ffffff;
        transition: all 0.15s ease-in-out;
    }
    .pagination .page-item.active .page-link {
        background-color: #1b7a5a !important;
        border-color: #1b7a5a !important;
        color: #ffffff !important;
        font-weight: 600;
        box-shadow: 0 2px 6px rgba(27, 122, 90, 0.25);
    }
    .pagination .page-item .page-link:hover {
        background-color: #e8f5f0;
        border-color: #1b7a5a;
        color: #1b7a5a;
    }
    .pagination .page-item.disabled .page-link {
        color: #adb5bd;
        background-color: #f8f9fa;
        border-color: #e9ecef;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Header Page -->
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
    <div>
        <h4 class="mb-1 fw-bold text-dark d-flex align-items-center gap-2">
            <span class="p-2 rounded-circle bg-success-subtle text-success d-inline-flex align-items-center justify-content-center" style="width:38px;height:38px">
                <i class="bi bi-shield-check fs-5"></i>
            </span>
            <span>Rekap Aktivitas IT & Pelacakan Data</span>
        </h4>
        <div class="text-muted small">Catatan riwayat siapa yang menginput, mengubah, dan menghapus jadwal operasi maupun data master untuk pelacakan kendala.</div>
    </div>
    <div class="d-flex align-items-center gap-2 flex-wrap">
        <a href="<?php echo e(route('admin.activity_logs.index')); ?>" class="btn btn-outline-secondary btn-sm px-3" title="Segarkan dan kembalikan ke setelan awal">
            <i class="bi bi-arrow-clockwise me-1"></i>Reset
        </a>
        <?php if(auth()->user()->canAccess('backup.manage')): ?>
        <a href="<?php echo e(route('admin.backups.index')); ?>" class="btn btn-rs btn-sm px-3 shadow-sm">
            <i class="bi bi-database-check me-1"></i>Ke Backup & Restore
        </a>
        <?php endif; ?>
    </div>
</div>

<!-- 4 Symmetrical Stat Cards -->
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
        <div class="card stat-card shadow-sm p-3 h-100 bg-white" style="border-top: 4px solid #1b7a5a !important;">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <div class="text-muted small text-uppercase fw-semibold" style="letter-spacing:.3px">Total Log Tercatat</div>
                    <div class="fs-4 fw-bold text-dark mt-1"><?php echo e(number_format($stats['total'])); ?></div>
                    <small class="text-success fw-medium"><i class="bi bi-clock-history me-1"></i>Hari ini: <?php echo e(number_format($stats['today_total'])); ?></small>
                </div>
                <div class="stat-icon bg-success-subtle text-success">
                    <i class="bi bi-journal-text"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="card stat-card shadow-sm p-3 h-100 bg-white" style="border-top: 4px solid #198754 !important;">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <div class="text-muted small text-uppercase fw-semibold" style="letter-spacing:.3px">Total Input / Tambah</div>
                    <div class="fs-4 fw-bold text-success mt-1"><?php echo e(number_format($stats['total_input'])); ?></div>
                    <small class="text-muted">Data jadwal & master baru</small>
                </div>
                <div class="stat-icon bg-success-subtle text-success">
                    <i class="bi bi-plus-circle"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="card stat-card shadow-sm p-3 h-100 bg-white" style="border-top: 4px solid #e69500 !important;">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <div class="text-muted small text-uppercase fw-semibold" style="letter-spacing:.3px">Total Perubahan</div>
                    <div class="fs-4 fw-bold text-warning-emphasis mt-1"><?php echo e(number_format($stats['total_ubah'])); ?></div>
                    <small class="text-muted">Perubahan data / pindah jadwal</small>
                </div>
                <div class="stat-icon bg-warning-subtle text-warning-emphasis">
                    <i class="bi bi-pencil-square"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="card stat-card shadow-sm p-3 h-100 bg-white" style="border-top: 4px solid #dc3545 !important;">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <div class="text-muted small text-uppercase fw-semibold" style="letter-spacing:.3px">Total Hapus Data</div>
                    <div class="fs-4 fw-bold text-danger mt-1"><?php echo e(number_format($stats['total_hapus'])); ?></div>
                    <small class="text-danger fw-semibold"><i class="bi bi-exclamation-triangle me-1"></i>Pelacakan penting IT</small>
                </div>
                <div class="stat-icon bg-danger-subtle text-danger">
                    <i class="bi bi-trash3"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Symmetrical Filter Bar -->
<div class="card filter-card shadow-sm p-3 mb-4 bg-white">
    <form method="GET" action="<?php echo e(route('admin.activity_logs.index')); ?>" class="row g-2 align-items-end" id="filterForm">
        <!-- Cari Kata Kunci -->
        <div class="col-lg-3 col-md-6">
            <label class="form-label small fw-semibold text-muted mb-1"><i class="bi bi-search me-1"></i>Cari Kata Kunci / Pasien / Petugas</label>
            <div class="input-group">
                <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-search"></i></span>
                <input type="text" name="q" class="form-control border-start-0" placeholder="Ketik nama, RM, user, IP..." value="<?php echo e(request('q')); ?>" autocomplete="off">
            </div>
        </div>

        <!-- Jenis Aksi -->
        <div class="col-lg-2 col-md-3">
            <label class="form-label small fw-semibold text-muted mb-1"><i class="bi bi-tag me-1"></i>Jenis Aksi</label>
            <select name="action" class="form-select">
                <option value="">Semua Aksi</option>
                <option value="INPUT" <?php if(request('action') === 'INPUT'): echo 'selected'; endif; ?>>INPUT (Tambah)</option>
                <option value="UBAH" <?php if(request('action') === 'UBAH'): echo 'selected'; endif; ?>>UBAH (Edit / Pindah)</option>
                <option value="HAPUS" <?php if(request('action') === 'HAPUS'): echo 'selected'; endif; ?>>HAPUS (Delete)</option>
                <option value="SALIN" <?php if(request('action') === 'SALIN'): echo 'selected'; endif; ?>>SALIN (Copy)</option>
                <option value="RESTORE" <?php if(request('action') === 'RESTORE'): echo 'selected'; endif; ?>>RESTORE (Pulihkan)</option>
                <option value="BACKUP" <?php if(request('action') === 'BACKUP'): echo 'selected'; endif; ?>>BACKUP (Cadangkan)</option>
            </select>
        </div>

        <!-- Modul -->
        <div class="col-lg-2 col-md-3">
            <label class="form-label small fw-semibold text-muted mb-1"><i class="bi bi-layers me-1"></i>Modul</label>
            <select name="module" class="form-select">
                <option value="">Semua Modul</option>
                <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($m); ?>" <?php if(request('module') === $m): echo 'selected'; endif; ?>><?php echo e($m); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Tanggal -->
        <div class="col-lg-2 col-md-4">
            <label class="form-label small fw-semibold text-muted mb-1"><i class="bi bi-calendar3 me-1"></i>Tanggal</label>
            <input type="date" name="date" class="form-control" value="<?php echo e(request('date')); ?>">
        </div>

        <!-- Tampilkan Log (10, 100, 1000) -->
        <div class="col-lg-1 col-md-2">
            <label class="form-label small fw-semibold text-muted mb-1"><i class="bi bi-list-ol me-1"></i>Tampilkan</label>
            <select name="per_page" class="form-select" onchange="document.getElementById('filterForm').submit()">
                <option value="10" <?php if($perPage == 10): echo 'selected'; endif; ?>>10</option>
                <option value="25" <?php if($perPage == 25): echo 'selected'; endif; ?>>25</option>
                <option value="50" <?php if($perPage == 50): echo 'selected'; endif; ?>>50</option>
                <option value="100" <?php if($perPage == 100): echo 'selected'; endif; ?>>100</option>
                <option value="500" <?php if($perPage == 500): echo 'selected'; endif; ?>>500</option>
                <option value="1000" <?php if($perPage == 1000): echo 'selected'; endif; ?>>1.000</option>
            </select>
        </div>

        <!-- Tombol Aksi Simetris -->
        <div class="col-lg-2 col-md-6 d-flex gap-2">
            <button type="submit" class="btn btn-rs flex-fill d-flex align-items-center justify-content-center gap-1 shadow-sm">
                <i class="bi bi-funnel"></i><span>Filter</span>
            </button>
            <a href="<?php echo e(route('admin.activity_logs.index')); ?>" class="btn btn-outline-secondary d-flex align-items-center justify-content-center" style="width: 44px;" title="Reset Semua Filter">
                <i class="bi bi-x-lg"></i>
            </a>
        </div>
    </form>
</div>

<!-- Table Card -->
<div class="card table-card shadow-sm p-4 bg-white">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3 pb-2 border-bottom">
        <div>
            <h6 class="mb-0 fw-bold text-dark d-flex align-items-center gap-2">
                <span>Daftar Rekap Aktivitas</span>
                <span class="badge rounded-pill bg-light text-dark border"><?php echo e(number_format($logs->total())); ?> catatan</span>
            </h6>
        </div>

        <!-- Quick Per-Page Switcher (10, 100, 1000) -->
        <div class="d-flex align-items-center gap-2">
            <span class="small text-muted fw-semibold d-none d-sm-inline">Tampilkan:</span>
            <div class="btn-group btn-group-sm" role="group">
                <?php ($currentParams = request()->except('per_page', 'page')); ?>
                <a href="<?php echo e(route('admin.activity_logs.index', array_merge($currentParams, ['per_page' => 10]))); ?>" 
                   class="btn btn-outline-success <?php echo e($perPage == 10 ? 'active' : ''); ?>">10</a>
                <a href="<?php echo e(route('admin.activity_logs.index', array_merge($currentParams, ['per_page' => 100]))); ?>" 
                   class="btn btn-outline-success <?php echo e($perPage == 100 ? 'active' : ''); ?>">100</a>
                <a href="<?php echo e(route('admin.activity_logs.index', array_merge($currentParams, ['per_page' => 1000]))); ?>" 
                   class="btn btn-outline-success <?php echo e($perPage == 1000 ? 'active' : ''); ?>">1.000</a>
            </div>
            <span class="small text-muted d-none d-md-inline">log / halaman</span>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-hover table-activity align-middle mb-0">
            <thead>
                <tr>
                    <th style="width: 140px;">WAKTU</th>
                    <th style="width: 170px;">USER / PETUGAS</th>
                    <th style="width: 100px;" class="text-center">AKSI</th>
                    <th style="width: 120px;" class="text-center">MODUL</th>
                    <th>KETERANGAN AKTIVITAS</th>
                    <th style="width: 70px;" class="text-center">DETAIL</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <!-- Waktu -->
                    <td class="text-nowrap">
                        <div class="fw-semibold text-dark"><?php echo e($log->created_at->format('d/m/Y')); ?></div>
                        <small class="text-muted"><i class="bi bi-clock me-1"></i><?php echo e($log->created_at->format('H:i:s')); ?> WIB</small>
                    </td>

                    <!-- User / Petugas -->
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <span class="rounded-circle bg-light border d-inline-flex align-items-center justify-content-center text-secondary fw-bold flex-shrink-0" style="width:32px;height:32px;font-size:12px">
                                <?php echo e(strtoupper(substr($log->user_name ?? 'U', 0, 1))); ?>

                            </span>
                            <div class="overflow-hidden">
                                <div class="fw-semibold text-dark text-truncate small" style="max-width: 135px;" title="<?php echo e($log->user_name); ?>"><?php echo e($log->user_name ?? 'Anonim'); ?></div>
                                <small class="text-muted d-block text-truncate font-monospace" style="font-size: 11px;"><?php echo e('@' . ($log->user_username ?? 'system')); ?></small>
                            </div>
                        </div>
                    </td>

                    <!-- Aksi -->
                    <td class="text-center">
                        <?php switch($log->action):
                            case ('INPUT'): ?>
                                <span class="badge text-bg-success badge-action"><i class="bi bi-plus-circle me-1"></i>INPUT</span>
                                <?php break; ?>
                            <?php case ('UBAH'): ?>
                                <span class="badge text-bg-warning text-dark badge-action"><i class="bi bi-pencil me-1"></i>UBAH</span>
                                <?php break; ?>
                            <?php case ('HAPUS'): ?>
                                <span class="badge text-bg-danger badge-action"><i class="bi bi-trash3-fill me-1"></i>HAPUS</span>
                                <?php break; ?>
                            <?php case ('SALIN'): ?>
                                <span class="badge text-bg-info text-white badge-action"><i class="bi bi-copy me-1"></i>SALIN</span>
                                <?php break; ?>
                            <?php case ('RESTORE'): ?>
                                <span class="badge text-bg-primary badge-action"><i class="bi bi-arrow-counterclockwise me-1"></i>RESTORE</span>
                                <?php break; ?>
                            <?php case ('BACKUP'): ?>
                                <span class="badge text-bg-dark badge-action"><i class="bi bi-database me-1"></i>BACKUP</span>
                                <?php break; ?>
                            <?php default: ?>
                                <span class="badge text-bg-secondary badge-action"><?php echo e($log->action); ?></span>
                        <?php endswitch; ?>
                    </td>

                    <!-- Modul -->
                    <td class="text-center">
                        <span class="badge bg-light text-dark border px-2 py-1 small fw-normal"><?php echo e($log->module); ?></span>
                    </td>

                    <!-- Keterangan -->
                    <td>
                        <div class="text-break text-dark"><?php echo e($log->description); ?></div>
                        <?php if($log->patient_name): ?>
                        <small class="text-muted d-block mt-1">
                            <span class="badge bg-light text-secondary border me-1"><i class="bi bi-person me-1"></i>Pasien: <b><?php echo e($log->patient_name); ?></b></span>
                            <?php if($log->operation_date): ?>
                            <span class="badge bg-light text-secondary border"><i class="bi bi-calendar-event me-1"></i>Tgl Operasi: <?php echo e($log->operation_date->format('d/m/Y')); ?></span>
                            <?php endif; ?>
                        </small>
                        <?php endif; ?>
                    </td>

                    <!-- Detail Modal Trigger -->
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-outline-primary p-1 px-2 btn-detail" 
                                data-bs-toggle="modal" 
                                data-bs-target="#detailModal"
                                data-id="<?php echo e($log->id); ?>"
                                data-action="<?php echo e($log->action); ?>"
                                data-module="<?php echo e($log->module); ?>"
                                data-user="<?php echo e($log->user_name); ?> ({{ $log->user_username }})"
                                data-time="<?php echo e($log->created_at->format('d/m/Y H:i:s')); ?> WIB"
                                data-desc="<?php echo e($log->description); ?>"
                                data-ip="<?php echo e($log->ip_address); ?>"
                                data-ua="<?php echo e($log->user_agent); ?>"
                                data-old='<?php echo json_encode($log->old_values, 15, 512) ?>'
                                data-new='<?php echo json_encode($log->new_values, 15, 512) ?>'
                                title="Lihat Snapshot Lengkap">
                            <i class="bi bi-search"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center py-5 text-muted">
                        <i class="bi bi-journal-x fs-1 d-block mb-2 text-secondary opacity-50"></i>
                        <h6 class="fw-semibold">Belum ada catatan aktivitas</h6>
                        <small class="text-muted">Tidak ada log yang cocok dengan filter yang Anda tentukan.</small>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Symmetrical Table Footer -->
    <div class="mt-4 pt-3 border-top d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div class="small text-muted">
            Menampilkan <b><?php echo e($logs->firstItem() ?? 0); ?></b> - <b><?php echo e($logs->lastItem() ?? 0); ?></b> dari <b><?php echo e(number_format($logs->total())); ?></b> catatan
            <span class="mx-1">•</span>
            <span>Limit: <b><?php echo e($perPage); ?></b> baris / halaman</span>
        </div>
        <div>
            <?php echo e($logs->links()); ?>

        </div>
    </div>
</div>

<!-- Modal Detail Snapshot -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg" style="border-radius:14px;overflow:hidden">
            <div class="modal-header text-white" id="modalHeader" style="background: #1b7a5a;">
                <h5 class="modal-title fs-6 fw-bold"><i class="bi bi-shield-check me-2"></i>Rincian Snapshot Pelacakan Aktivitas</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="card bg-light border-0 p-3 mb-3" style="border-radius: 10px;">
                    <div class="row g-2">
                        <div class="col-sm-6">
                            <small class="text-muted d-block">Pelaku / Petugas:</small>
                            <span class="fw-bold text-dark" id="modalUser">-</span>
                        </div>
                        <div class="col-sm-6">
                            <small class="text-muted d-block">Waktu Eksekusi:</small>
                            <span class="fw-bold text-dark" id="modalTime">-</span>
                        </div>
                        <div class="col-sm-6">
                            <small class="text-muted d-block">Jenis Aksi & Modul:</small>
                            <span class="badge text-bg-primary me-1" id="modalAction">-</span>
                            <span class="badge bg-secondary" id="modalModule">-</span>
                        </div>
                        <div class="col-sm-6">
                            <small class="text-muted d-block">IP Address & Browser:</small>
                            <code class="small text-dark" id="modalIp">-</code>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold text-dark">Keterangan Aktivitas:</label>
                    <div class="p-3 border rounded bg-white text-dark small" id="modalDesc">-</div>
                </div>

                <!-- Snapshot Data View -->
                <div id="snapshotSection">
                    <label class="form-label fw-bold text-dark d-flex justify-content-between align-items-center">
                        <span>Snapshot Data (Data Tersimpan / Dihapus):</span>
                        <span class="badge bg-info text-white" id="snapshotBadge">Snapshot</span>
                    </label>

                    <div id="snapshotContainer" class="p-3 border rounded bg-light" style="max-height: 300px; overflow-y: auto; font-family: monospace; font-size: 0.85rem;">
                        <!-- Injected by JavaScript -->
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-secondary btn-sm px-4" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const modal = document.getElementById('detailModal');
        modal.addEventListener('show.bs.modal', function (event) {
            const btn = event.relatedTarget;
            const action = btn.getAttribute('data-action');
            const module = btn.getAttribute('data-module');
            const user = btn.getAttribute('data-user');
            const time = btn.getAttribute('data-time');
            const desc = btn.getAttribute('data-desc');
            const ip = btn.getAttribute('data-ip') || '-';
            const ua = btn.getAttribute('data-ua') || '-';
            const oldValRaw = btn.getAttribute('data-old');
            const newValRaw = btn.getAttribute('data-new');

            document.getElementById('modalUser').textContent = user;
            document.getElementById('modalTime').textContent = time;
            document.getElementById('modalAction').textContent = action;
            document.getElementById('modalModule').textContent = module;
            document.getElementById('modalDesc').textContent = desc;
            document.getElementById('modalIp').textContent = ip + ' (' + ua.substring(0, 45) + '...)';

            const header = document.getElementById('modalHeader');
            if (action === 'HAPUS') {
                header.style.background = '#dc3545';
            } else if (action === 'INPUT') {
                header.style.background = '#198754';
            } else if (action === 'UBAH') {
                header.style.background = '#e69500';
            } else {
                header.style.background = '#1b7a5a';
            }

            let oldVal = null;
            let newVal = null;
            try { oldVal = oldValRaw ? JSON.parse(oldValRaw) : null; } catch(e){}
            try { newVal = newValRaw ? JSON.parse(newValRaw) : null; } catch(e){}

            const container = document.getElementById('snapshotContainer');
            const badge = document.getElementById('snapshotBadge');

            if (action === 'HAPUS') {
                badge.className = 'badge bg-danger';
                badge.textContent = 'Data yang Dihapus';
                container.innerHTML = oldVal 
                    ? '<pre class="mb-0 text-danger-emphasis">' + JSON.stringify(oldVal, null, 2) + '</pre>' 
                    : '<div class="text-muted">Tidak ada snapshot khusus.</div>';
            } else if (action === 'INPUT') {
                badge.className = 'badge bg-success';
                badge.textContent = 'Data Baru yang Diinput';
                container.innerHTML = newVal 
                    ? '<pre class="mb-0 text-success-emphasis">' + JSON.stringify(newVal, null, 2) + '</pre>' 
                    : '<div class="text-muted">Tidak ada snapshot khusus.</div>';
            } else if (action === 'UBAH') {
                badge.className = 'badge bg-warning text-dark';
                badge.textContent = 'Perubahan (Lama & Baru)';
                let html = '<div class="row g-2">';
                html += '<div class="col-md-6"><b>Data Sebelum:</b><pre class="p-2 border rounded bg-white text-danger mt-1" style="font-size:11px">' + JSON.stringify(oldVal || {}, null, 2) + '</pre></div>';
                html += '<div class="col-md-6"><b>Data Sesudah:</b><pre class="p-2 border rounded bg-white text-success mt-1" style="font-size:11px">' + JSON.stringify(newVal || {}, null, 2) + '</pre></div>';
                html += '</div>';
                container.innerHTML = html;
            } else {
                badge.className = 'badge bg-info text-white';
                badge.textContent = 'Snapshot Data';
                container.innerHTML = '<pre class="mb-0">' + JSON.stringify(newVal || oldVal || {}, null, 2) + '</pre>';
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\okrsma1\resources\views/admin/activity_logs/index.blade.php ENDPATH**/ ?>